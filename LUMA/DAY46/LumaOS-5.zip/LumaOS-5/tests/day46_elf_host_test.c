/* tests/day46_elf_host_test.c - Day 46 host unit test of elf_run()'s C logic.
 *
 *   gcc -O1 -Wall -Ikernel/exec -Ikernel/gui -Ikernel/lib -Ikernel/core \
 *       -Ikernel/drivers -Ikernel/arch -Ikernel/fs/vfs tests/day46_elf_host_test.c \
 *       kernel/exec/elf.c kernel/exec/elf_run.c -o /tmp/elf46_host_test && /tmp/elf46_host_test
 *
 * The assembly trampoline (elf_enter) and the terminal are replaced by stubs here, so this
 * checks only what elf_run.c itself decides: argument checks, "loaded must be 1", the
 * re-validation of a (possibly tampered) image, the entry address / api table it hands to the
 * trampoline, exit-code propagation, the loaded->0 rule, and the api->puts/putchar bridge.
 * The trampoline itself (registers, DF, IF, segments, esp) is tested in QEMU:
 * tests/day46_test_elf_run.py.
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "elf_run.h"

static int fails;
#define CHECK(c, ...) do { if (c) printf("PASS "); else { printf("FAIL "); fails++; } \
                           printf(__VA_ARGS__); printf("\n"); } while (0)

/* ---- stubs ---- */
static char     out_buf[8192];
static unsigned out_len;
void terminal_putchar(terminal_t *t, char c, unsigned char color)
{ (void)t; (void)color; if (out_len < sizeof(out_buf) - 1) out_buf[out_len++] = c; }
void terminal_puts(terminal_t *t, const char *s, unsigned char color)
{ while (*s) terminal_putchar(t, *s++, color); }

static int      enter_calls;
static uint32_t enter_entry;
static const luma_api_t *enter_api;
static int      enter_ret = 42;
static const char *enter_say;          /* what the fake program prints through api->puts */
int elf_enter(uint32_t entry, const void *api)
{
    enter_calls++;
    enter_entry = entry;
    enter_api = (const luma_api_t *)api;
    if (enter_say) enter_api->puts(enter_say);
    enter_api->putchar('!');
    return enter_ret;
}

/* ---- a hand-built, valid, loaded image: one RX segment at 0x08048000 ---- */
static void mk(elf_image_t *img)
{
    memset(img, 0, sizeof(*img));
    img->file_size = 0x200;
    elf32_ehdr_t *h = &img->ehdr;
    memcpy(h->e_ident, "\x7f""ELF\x01\x01\x01", 7);
    h->e_type = ET_EXEC; h->e_machine = EM_386; h->e_version = 1;
    h->e_entry = 0x08048080; h->e_phoff = 52; h->e_ehsize = 52;
    h->e_phentsize = 32; h->e_phnum = 2;
    elf32_phdr_t *p = &img->phdr[0];
    p->p_type = PT_LOAD; p->p_offset = 0; p->p_vaddr = p->p_paddr = 0x08048000;
    p->p_filesz = p->p_memsz = 0x100; p->p_flags = PF_R | PF_X; p->p_align = 0x1000;
    p = &img->phdr[1];
    p->p_type = PT_LOAD; p->p_offset = 0x100; p->p_vaddr = p->p_paddr = 0x08049100;
    p->p_filesz = 0x40; p->p_memsz = 0x240; p->p_flags = PF_R | PF_W; p->p_align = 0x1000;
    img->loaded = 1;
}

int main(void)
{
    elf_image_t img;
    terminal_t *T = (terminal_t *)0x1000;      /* never dereferenced: stubs ignore it */
    int code = -999, rc;

    /* ---- argument checks ---- */
    mk(&img);
    CHECK(elf_run(NULL, T, &code) == ELF_ERR_NULL, "NULL img -> ELF_ERR_NULL");
    CHECK(elf_run(&img, NULL, &code) == ELF_ERR_NULL, "NULL terminal -> ELF_ERR_NULL");
    CHECK(enter_calls == 0, "nothing executed after the NULL cases");

    /* ---- loaded gate ---- */
    mk(&img); img.loaded = 0; code = -999;
    rc = elf_run(&img, T, &code);
    CHECK(rc == ELF_ERR_NOT_LOADED, "loaded==0 -> ELF_ERR_NOT_LOADED (got %d)", rc);
    CHECK(code == 0, "exit_code zeroed on failure (got %d)", code);
    CHECK(enter_calls == 0, "loaded==0: trampoline NOT called");
    mk(&img); img.loaded = 2;
    CHECK(elf_run(&img, T, &code) == ELF_ERR_NOT_LOADED && enter_calls == 0, "loaded==2 (not exactly 1) refused too");

    /* ---- tampered images are re-validated (loaded==1 is not enough) ---- */
    mk(&img); img.ehdr.e_machine = 62;
    CHECK(elf_run(&img, T, &code) == ELF_ERR_BAD_MACHINE && enter_calls == 0, "tampered e_machine refused");
    mk(&img); img.ehdr.e_entry = 0x08049100;        /* inside a RW (non-exec) segment */
    rc = elf_run(&img, T, &code);
    CHECK(rc == ELF_ERR_ENTRY_NOT_EXEC && enter_calls == 0, "entry in non-exec segment refused (got %d)", rc);
    mk(&img); img.ehdr.e_entry = 0x08048100;        /* one past the exec segment's file part */
    CHECK(elf_run(&img, T, &code) == ELF_ERR_ENTRY_NOT_EXEC && enter_calls == 0, "entry one past segment end refused");
    mk(&img); img.ehdr.e_entry = 0x00010000;        /* kernel memory */
    CHECK(elf_run(&img, T, &code) != ELF_OK && enter_calls == 0, "entry in kernel memory refused");
    mk(&img); img.phdr[0].p_vaddr = 0x00100000;     /* segment moved onto kernel stack area */
    CHECK(elf_run(&img, T, &code) != ELF_OK && enter_calls == 0, "segment outside the user load area refused");
    mk(&img); img.entry_seg = 1;                    /* lying entry_seg field must not matter... */
    rc = elf_run(&img, T, &code);
    CHECK(rc == ELF_OK && enter_calls == 1 && enter_entry == 0x08048080,
          "wrong img.entry_seg is ignored: validation recomputes it (rc %d, entry %08x)", rc, enter_entry);

    /* ---- the good path ---- */
    enter_calls = 0; out_len = 0; enter_ret = 42; enter_say = "hi, ";
    mk(&img); code = -999;
    rc = elf_run(&img, T, &code);
    CHECK(rc == ELF_OK, "valid loaded image -> ELF_OK");
    CHECK(enter_calls == 1, "trampoline called exactly once");
    CHECK(enter_entry == 0x08048080, "entry passed = e_entry (0x%08x)", enter_entry);
    CHECK(code == 42, "exit code = trampoline's return value (%d)", code);
    CHECK(img.loaded == 0, "img.loaded cleared after running (memory image is no longer pristine)");
    CHECK(enter_api && enter_api->magic == LUMA_API_MAGIC && enter_api->version == LUMA_API_VERSION,
          "api table: magic 'LAPI', version %u", enter_api ? enter_api->version : 0);
    CHECK(out_len == 5 && memcmp(out_buf, "hi, !", 5) == 0, "api->puts/putchar reach the terminal (\"%.*s\")", (int)out_len, out_buf);

    /* running again without re-loading is refused */
    enter_calls = 0;
    CHECK(elf_run(&img, T, &code) == ELF_ERR_NOT_LOADED && enter_calls == 0, "second run without reload refused");

    /* negative / large exit codes pass through unchanged */
    mk(&img); enter_ret = -1;
    elf_run(&img, T, &code);
    CHECK(code == -1, "exit code -1 preserved");
    mk(&img); enter_ret = (int)0x80000000;
    elf_run(&img, T, &code);
    CHECK(code == (int)0x80000000, "exit code INT_MIN preserved");

    /* exit_code pointer is optional */
    mk(&img);
    CHECK(elf_run(&img, T, NULL) == ELF_OK, "exit_code == NULL allowed");

    /* ---- api outside a run: puts after elf_run returned must be a no-op ---- */
    const luma_api_t *saved = enter_api;
    out_len = 0;
    saved->puts("late");
    saved->putchar('x');
    CHECK(out_len == 0, "api->puts/putchar after the program finished print nothing");

    /* ---- api->puts robustness: NULL and unterminated strings ---- */
    static const char *capture_api_say;
    (void)capture_api_say;
    mk(&img); enter_say = NULL; out_len = 0; enter_ret = 0;
    /* fake program that calls puts(NULL) and an unterminated 8000-byte buffer */
    {
        static char big[8000];
        memset(big, 'z', sizeof(big));          /* no NUL anywhere */
        enter_say = big;
        elf_run(&img, T, &code);
        CHECK(out_len <= 4097 + 1, "unterminated string is capped (printed %u chars)", out_len);
    }

    printf("\n%s (%d failure%s)\n", fails ? "FAILED" : "ALL PASS", fails, fails == 1 ? "" : "s");
    return fails ? 1 : 0;
}
