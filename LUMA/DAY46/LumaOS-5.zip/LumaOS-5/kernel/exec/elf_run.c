/* kernel/exec/elf_run.c
 * LumaOS 5.0 - elf_run(): 跳到已装入内存的 ELF 入口点并执行
 *
 * DAY46 (Week 7, Day 46): "实现 elf_run()。"  验收："hello.sw 可以执行。"
 * 原理见 elf.h 的 DAY46 注释，接口见 elf_run.h，跳板见 elf_enter.asm。
 */
#include "elf_run.h"
#include "../lib/string.h"

/* 汇编跳板：存现场 -> call entry(api) -> 恢复现场，返回程序的 eax。 */
extern int elf_enter(uint32_t entry, const void *api);

/* ---- 给程序用的“内核服务”（luma_api_t 的实现） ---- */

/* 当前正在运行的程序把输出送到哪个终端。elf_run() 进入前设置、返回后清空。 */
static terminal_t *g_run_out;

/* 一次 puts 最多输出多少字符：程序给的指针指向哪、有没有 NUL 都不可信，
 * 设个上限，免得一个忘了写 '\0' 的字符串把整个内存当文字刷屏到天荒地老。 */
#define API_PUTS_MAX  4096

static void api_putchar(int c)
{
    if (g_run_out)
        terminal_putchar(g_run_out, (char)c, TERM_COL_DEFAULT);
}

static void api_puts(const char *s)
{
    if (!g_run_out || !s)
        return;
    for (int i = 0; i < API_PUTS_MAX && s[i]; i++)
        terminal_putchar(g_run_out, s[i], TERM_COL_DEFAULT);
}

static const luma_api_t g_api = {
    LUMA_API_MAGIC,
    LUMA_API_VERSION,
    api_puts,
    api_putchar,
};

int elf_run(elf_image_t *img, terminal_t *out, int *exit_code)
{
    if (exit_code)
        *exit_code = 0;
    if (img == (elf_image_t *)0 || out == (terminal_t *)0)
        return ELF_ERR_NULL;

    /* 1. 只认“已装入”的映像：loaded 只有 elf_load_segments() 全部成功才会置 1。 */
    if (img->loaded != 1)
        return ELF_ERR_NOT_LOADED;

    /* 2. 不信任 img：重新校验。静态变量——elf_image_t 约 450 字节，不放内核栈。
     *    elf32_check_phdrs() 会整体重写它的 *img 参数，所以用一份临时拷贝。 */
    static elf_image_t chk;
    int rc = elf32_check_header(&img->ehdr, img->file_size);
    if (rc != ELF_OK)
        return rc;
    if (img->ehdr.e_phnum > ELF_MAX_PHDRS)
        return ELF_ERR_TOO_MANY_PHDRS;
    {
        elf32_ehdr_t eh = img->ehdr;
        rc = elf32_check_phdrs(&eh, img->phdr, img->ehdr.e_phnum,
                               img->file_size, &chk);
        if (rc != ELF_OK)
            return rc;
    }

    /* 入口点：校验函数已保证它落在某个带 PF_X 的 PT_LOAD 的文件部分里，
     * 这里再用“校验结果”（chk，而不是调用者传来的 img->entry_seg）确认一次。
     * 因为 img->entry_seg 也是调用者可以改的字段。 */
    const elf32_phdr_t *es = &chk.phdr[chk.entry_seg];
    uint32_t entry = chk.ehdr.e_entry;
    if (es->p_type != PT_LOAD || !(es->p_flags & PF_X) ||
        entry < es->p_vaddr || entry - es->p_vaddr >= es->p_filesz)
        return ELF_ERR_ENTRY_NOT_EXEC;

    /* 3. 跳进去。g_run_out 在进入前设好，返回后清掉（程序只在运行期间能打印）。 */
    g_run_out = out;
    int code = elf_enter(entry, &g_api);
    g_run_out = (terminal_t *)0;

    /* 4. 程序已经改写过自己的 .data/.bss：这份内存映像不再“干净”。 */
    img->loaded = 0;

    if (exit_code)
        *exit_code = code;
    return ELF_OK;
}
