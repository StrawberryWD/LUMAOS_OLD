/* kernel/exec/elf_run.h
 * LumaOS 5.0 - elf_run(): 跳到已装入内存的 ELF 入口点并执行
 *
 * DAY46 (Week 7, Day 46): "实现 elf_run()。"  验收："hello.sw 可以执行。"
 *
 * 原理见 elf.h 的 DAY46 注释；汇编跳板见 elf_enter.asm。
 *
 * 加载 → 运行 的完整流程（今天第一次走通）：
 *     elf_load()           Day 44  打开 + 验证      -> elf_image_t（loaded=0）
 *     elf_load_segments()  Day 45  段装入 p_vaddr   -> loaded=1
 *     elf_run()            Day 46  跳到 e_entry     -> 程序 ret 回来，得到退出码
 */
#ifndef LUMA_ELF_RUN_H
#define LUMA_ELF_RUN_H

#include <stdint.h>
#include "elf.h"
#include "../gui/gui.h"

/* ---------------------------------------------------------------------
 * 临时的“内核服务表” luma_api_t（Day 46 ~ Day 50 的过渡品）
 * ---------------------------------------------------------------------
 * 程序跑起来之后总得“说点什么”才看得出它跑过。可系统调用（int 0x80，
 * Day 50~51）今天还没有，所以内核先把一张函数表的地址作为唯一参数传给
 * 程序入口：
 *       int _start(const luma_api_t *api);
 * 程序调用 api->puts("...") 就等于直接调用内核函数——这只有在程序和内核
 * 同处 Ring 0、共享地址空间的今天才成立（也因此程序可以随便写内核内存，
 * 今天没有任何保护；Day 55 才降到 Ring 3）。Day 50 之后这张表会整个消失，
 * 换成 int 0x80 + 系统调用号，程序源码里的 api->puts(s) 变成 sys_write()。
 *
 * 表的布局就是 ABI：新增字段只能加在末尾，version 同步 +1。
 * 所有函数都是 cdecl（参数从右到左压栈，调用者清栈，返回值在 eax）。 */
#define LUMA_API_MAGIC    0x4950414Cu    /* 'L','A','P','I'（小端）*/
#define LUMA_API_VERSION  1u

typedef struct luma_api {
    uint32_t magic;                      /* LUMA_API_MAGIC：程序据此确认是 LumaOS 在调用它 */
    uint32_t version;                    /* LUMA_API_VERSION                               */
    void (*puts)(const char *s);         /* 向启动它的终端输出以 NUL 结尾的字符串（不自动换行） */
    void (*putchar)(int c);              /* 输出一个字符                                    */
} luma_api_t;

/* elf_run(img, out, exit_code)
 *
 * img       : elf_load() 验证、并由 elf_load_segments() 装入内存后的映像。
 *             必须 img->loaded == 1，否则返回 ELF_ERR_NOT_LOADED，一条指令也不执行。
 * out       : 程序调用 api->puts/putchar 时输出到哪个终端（不能为 NULL）。
 * exit_code : 可选输出（可传 NULL）：程序入口函数返回时 eax 的值。
 *
 * 做的事：
 *   1. 参数检查，loaded 必须为 1；
 *   2. 不信任 img：对其中的 Header + Program Header 重新校验一遍，并确认
 *      入口点仍落在可执行 PT_LOAD 的文件部分里（防止 img 在装载后被改过）；
 *   3. 把内核现场存起来，call e_entry（elf_enter.asm），程序 ret 后恢复；
 *   4. 把 img->loaded 置 0：程序运行会修改自己的 .data/.bss，内存里的映像
 *      已经不是“刚装载好的样子”，再跑一次必须重新 elf_load_segments()。
 * 返回 ELF_OK（程序返回了，*exit_code 是它的退出码）或 ELF_ERR_*。
 *
 * 局限（后续几天逐个解决）：程序若不返回（死循环）或崩溃，内核会跟着挂——
 * Day 47 给程序独立的栈与“退出路径”，Day 52 sys_exit，Day 56 用户态异常。 */
int elf_run(elf_image_t *img, terminal_t *out, int *exit_code);

#endif /* LUMA_ELF_RUN_H */
