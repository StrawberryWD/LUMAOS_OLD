; kernel/exec/elf_enter.asm - LumaOS 5.0
;
; DAY46 (Week 7, Day 46): "实现 elf_run()。"  验收："hello.sw 可以执行。"
;
; int elf_enter(uint32_t entry, const void *api);          (cdecl)
;
;   “真正跳进程序”的那一小段汇编。C 语言没法可靠地表达下面这些事，所以单独
;   写在这里；elf_run.c 负责所有检查，这里只负责“跳进去、再回来”。
;
;   做的事：
;     1. 把内核的现场整个存到（内核）栈上：EFLAGS、8 个通用寄存器(pushad)、
;        4 个段寄存器(ds/es/fs/gs)。程序是别人写的——它按 C 调用约定本来只需
;        保留 ebx/esi/edi/ebp，但我们不能假设它守规矩，所以全存；回来时全部
;        恢复，elf_run() 的调用者（shell）什么也察觉不到。
;     2. 记下此刻的 esp 到 elf_saved_esp。回来时无论程序把 esp 弄成什么样
;        （例如 `ret 4`、多 pop 了几次），都直接从这个值恢复，保证“栈平衡”
;        不取决于程序是否守规矩。（前提是程序最终执行了一条 ret 回到我们；
;        程序若乱跳/死循环/崩溃，Day 56 的“用户态异常处理”才能兜住——那是后话。）
;     3. 让 esp 按 16 字节对齐、DF=0（System V i386 ABI 对“进入一个 C 函数”
;        的要求；gcc -O2 生成的代码默认假定调用点 16 字节对齐），把 api 指针
;        作为唯一的 cdecl 参数压栈，然后 call entry。
;        于是程序看到的世界就是：  int _start(const luma_api_t *api)
;        [esp] = 返回地址（指向下面的 .back），[esp+4] = api。
;     4. 程序用一条普通的 `ret` 回来，eax = 它的“退出码”。我们把 eax 写进
;        保存区里 eax 那个槽，popad 之后它就成了本函数的返回值。
;
;   今天程序仍然在 Ring 0、与内核共用同一段栈和同一份地址空间，所以这一步其实
;   就是“一次 C 函数调用”。Day 47 会把它换成独立的用户栈，Day 55 才真正降到
;   Ring 3；那时这个函数会变成 iret，但“存现场 → 进入 → 回来恢复”的骨架不变。
;
;   不可重入：elf_saved_esp 只有一份。今天的 elfrun 命令不会在程序里再启动
;   程序；多任务（7.0）之后，这个槽会移进每个进程的结构体里。

BITS 32

section .text
global elf_enter

elf_enter:
    push ebp
    mov  ebp, esp
    pushfd                      ; [EFLAGS]
    pushad                      ; edi esi ebp esp ebx edx ecx eax（eax 在最高处）
    push ds
    push es
    push fs
    push gs
    ; 现在 esp 指向 gs；pushad 帧 = esp+16 .. esp+47，其中 eax 槽在 esp+16+28

    mov  eax, [ebp + 8]         ; entry
    mov  edx, [ebp + 12]        ; api
    mov  [elf_saved_esp], esp

    and  esp, 0xFFFFFFF0        ; 16 字节对齐
    sub  esp, 12                ; 再压 4 字节参数后，call 之前 esp % 16 == 0
    push edx                    ; 唯一参数：api
    cld                         ; DF=0（ABI 要求）
    call eax                    ; ===== 跳进程序 =====

.back:                          ; ===== 程序 ret 回到这里 =====
    ; 程序可能改过 ds/es（Ring 0 下它做得到）。先用 ss 把它们改回内核的平坦数据段，
    ; 否则下面读 [elf_saved_esp] 会用到被改坏的 ds。
    mov  dx, ss
    mov  ds, dx
    mov  es, dx
    mov  esp, [elf_saved_esp]   ; 无论程序怎么动过 esp，都从保存值恢复
    mov  [esp + 16 + 28], eax   ; 退出码 -> 保存区的 eax 槽
    pop  gs
    pop  fs
    pop  es
    pop  ds
    popad                       ; eax = 退出码；其余寄存器 = 进入前的值
    popfd                       ; 恢复 EFLAGS（包括 IF、DF）
    pop  ebp
    ret

section .bss
align 4
elf_saved_esp: resd 1

section .note.GNU-stack noalloc noexec nowrite progbits
