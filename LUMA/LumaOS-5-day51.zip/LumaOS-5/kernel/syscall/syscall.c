/* kernel/syscall/syscall.c - LumaOS 5.0
 * DAY50: "定义 syscall ABI。"  验收："`int 0x80` 能进入 Kernel。"
 * ABI 与原理见 syscall.h。
 *
 * 流程：用户 `int 0x80` -> idt[0x80] -> isr128 -> isr_common（存现场）-> isr_handler()
 *        -> syscall_dispatch(ctx)：读 ctx->eax（调用号）、ebx/ecx/edx/esi/edi/ebp（参数），
 *        查表调用，把返回值写进 ctx->eax -> isr_common 弹回寄存器 -> iret。
 */
#define LUMA_KERNEL_SIDE 1
#include "syscall.h"
#include "../arch/isr_context.h"

_Static_assert(LUMA_USER_LO == 0x01000000u && LUMA_USER_HI == 0x0F000000u,
               "keep in sync with ELF_LOAD_MIN_ADDR / ELF_LOAD_MAX_ADDR in kernel/exec/elf.h");

/* ---- 各个系统调用的实现。参数一律当成不可信的整数。 ---- */

/* SYS_NOP：什么也不做。 */
static int32_t sys_nop(uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4, uint32_t a5, uint32_t a6)
{
    (void)a1; (void)a2; (void)a3; (void)a4; (void)a5; (void)a6;
    return 0;
}

/* SYS_GETABI：ABI 版本号。 */
static int32_t sys_getabi(uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4, uint32_t a5, uint32_t a6)
{
    (void)a1; (void)a2; (void)a3; (void)a4; (void)a5; (void)a6;
    return LUMA_SYSCALL_ABI_VERSION;
}

/* ---- DAY51: 用户指针检查 ---- */

int luma_user_range_ok(uint32_t addr, uint32_t len)
{
    if (len == 0)
        return 1;
    if (addr < LUMA_USER_LO || addr >= LUMA_USER_HI)
        return 0;
    /* 不写 addr + len <= HI：addr 接近 4 GB 时会 32 位回绕成小数而通过检查。 */
    return len <= LUMA_USER_HI - addr;
}

int luma_copy_from_user(void *dst, uint32_t src, uint32_t n)
{
    if (!luma_user_range_ok(src, n))
        return -LUMA_EFAULT;
    const volatile uint8_t *s = (const volatile uint8_t *)(uintptr_t)src;
    uint8_t *d = (uint8_t *)dst;
    for (uint32_t i = 0; i < n; i++)
        d[i] = s[i];
    return 0;
}

/* SYS_WRITE(fd, buf, len)：见 syscall.h 的 DAY51 一节。检查顺序：fd -> len==0 -> 指针 -> 有无程序。 */
extern int elf_run_write(const char *buf, uint32_t n, int to_stderr);   /* kernel/exec/elf_run.c */

static int32_t sys_write(uint32_t fd, uint32_t buf, uint32_t len, uint32_t a4, uint32_t a5, uint32_t a6)
{
    (void)a4; (void)a5; (void)a6;
    if (fd != LUMA_STDOUT && fd != LUMA_STDERR)
        return -LUMA_EBADF;
    if (len == 0)
        return 0;
    if (len > LUMA_WRITE_MAX)
        len = LUMA_WRITE_MAX;                       /* 短写：只写前 4096 字节 */
    if (!luma_user_range_ok(buf, len))
        return -LUMA_EFAULT;                        /* 整块检查在先：失败时一个字节都不输出 */

    char chunk[128];
    uint32_t done = 0;
    while (done < len) {
        uint32_t n = len - done;
        if (n > sizeof(chunk)) n = sizeof(chunk);
        if (luma_copy_from_user(chunk, buf + done, n) != 0)
            return -LUMA_EFAULT;
        if (elf_run_write(chunk, n, fd == LUMA_STDERR) != 0)
            return -LUMA_EBADF;                     /* 没有程序在运行：没有终端可写 */
        done += n;
    }
    return (int32_t)done;
}

/* 调用表：下标 = 调用号；NULL = 没有这个调用（返回 -ENOSYS）。
 * SYS_EXIT / SYS_WRITE 的号码今天就占住了（ABI 已定），实现留给 Day 52 / Day 51。 */
static const syscall_fn_t syscall_table[LUMA_SYSCALL_MAX] = {
    [SYS_NOP]    = sys_nop,
    [SYS_EXIT]   = 0,
    [SYS_WRITE]  = sys_write,       /* DAY51 */
    [SYS_GETABI] = sys_getabi,
};

static syscall_stats_t g_stats;

const syscall_stats_t *syscall_get_stats(void) { return &g_stats; }
void syscall_reset_stats(void)
{
    syscall_stats_t z = {0};
    g_stats = z;
}

void syscall_dispatch(struct isr_context *c)
{
    isr_context_t *ctx = (isr_context_t *)c;
    uint32_t nr = ctx->eax;
    int32_t ret;

    if (nr < LUMA_SYSCALL_MAX && syscall_table[nr]) {
        ret = syscall_table[nr](ctx->ebx, ctx->ecx, ctx->edx, ctx->esi, ctx->edi, ctx->ebp);
    } else {
        ret = -LUMA_ENOSYS;
        g_stats.bad_calls++;
    }

    g_stats.calls++;
    g_stats.last_nr = nr;
    g_stats.last_ret = ret;
    g_stats.last_args[0] = ctx->ebx; g_stats.last_args[1] = ctx->ecx; g_stats.last_args[2] = ctx->edx;
    g_stats.last_args[3] = ctx->esi; g_stats.last_args[4] = ctx->edi; g_stats.last_args[5] = ctx->ebp;
    g_stats.last_eip = ctx->eip;
    g_stats.last_cs = ctx->cs;

    ctx->eax = (uint32_t)ret;            /* 返回值：isr_common 出口会 pop 进 eax */
}

void syscall_read_gate(syscall_gate_t *g)
{
    struct { uint16_t limit; uint32_t base; } __attribute__((packed)) idtr;
    __asm__ volatile ("sidt %0" : "=m"(idtr));
    const uint8_t *e = (const uint8_t *)(uintptr_t)(idtr.base + 8u * LUMA_SYSCALL_VECTOR);
    g->handler  = (uint32_t)e[0] | (uint32_t)e[1] << 8 | (uint32_t)e[6] << 16 | (uint32_t)e[7] << 24;
    g->selector = (uint16_t)(e[2] | e[3] << 8);
    g->type_attr = e[5];
}
