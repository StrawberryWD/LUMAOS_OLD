/* kernel/syscall/syscall.h - LumaOS 5.0
 *
 * DAY50 (Week 8, Day 50): "定义 syscall ABI。"  验收："`int 0x80` 能进入 Kernel。"
 *
 * ===================================================================================
 *  为什么需要系统调用
 * ===================================================================================
 *  Day 46~49 里，程序靠内核塞给它的一张函数表 luma_api_t 来“说话”：程序 call api->puts，
 *  就是直接调用内核里的函数。这只在程序和内核同处 Ring 0、共享地址空间时才行得通——
 *  程序知道内核函数的地址，也就能随便写内核内存。
 *
 *  Day 53~55 要给程序独立的地址空间并把它降到 Ring 3：那时程序根本看不见内核的地址，
 *  CPU 也禁止它直接 call 进去。Ring 3 的程序想让内核做事（输出、退出、读文件……），
 *  唯一合法的途径是执行一条“软件中断”指令：
 *
 *          int 0x80
 *
 *  所以今天先把这条通道的“合同”（ABI）定死：调用号放哪、参数放哪、返回值放哪、
 *  哪些寄存器被保留、出错怎么表示。以后每增加一个系统调用，只是在表里添一行。
 *
 * ===================================================================================
 *  `int 0x80` 到底发生了什么（硬件做的部分）
 * ===================================================================================
 *   1. CPU 取出 IDT[0x80]（idt.c 里装的那个“门”）。
 *   2. 权限检查：软件中断指令 `int n` 要求 门的 DPL >= 当前特权级 CPL（数值上），否则 #GP。
 *      0x80 这个门 DPL=3，所以 Ring 3 的程序允许 `int 0x80`；而 IDT 里所有别的门 DPL=0，
 *      用户程序执行 `int 14` 之类会被拦下——它不能假装发生了缺页。
 *   3. [Ring 3 -> Ring 0 时] CPU 从 TSS 取内核栈 (ss0:esp0) 并切换到它，再把用户的
 *      ss、esp 压到新栈上；[同在 Ring 0 时（今天）] 不换栈，直接压在当前栈上。
 *   4. CPU 压入 eflags、cs、eip（返回地址），再清 IF（因为这是“中断门”，不是“陷阱门”），
 *      跳到门里写的处理程序地址。
 *   5. 返回时 `iret` 把 eip/cs/eflags（以及切换过栈时的 esp/ss）弹回去，程序从 `int 0x80`
 *      的下一条指令继续，就像刚调用了一个普通函数。
 *
 *  软件做的部分：interrupts.asm 的 isr128 压入“假错误码 0 + 向量号 0x80”，进入公共代码
 *  isr_common（保存全部通用寄存器和 ds，把段寄存器换成内核数据段），调用 isr_handler()；
 *  它看到向量 0x80，调用本模块的 syscall_dispatch()。返回时公共代码把保存的寄存器原样
 *  弹回——所以分发器只要改写保存区里 eax 那一格，程序就“收到了返回值”。
 *
 *  为什么选 0x80？不是硬件规定，是 Linux/i386 的传统：8259 PIC 已被重映射到向量 32~47
 *  （pic.c），0x80 与它们和 CPU 异常（0~31）都不冲突；沿用这个编号，查资料、读别人代码最方便。
 *
 * ===================================================================================
 *  LumaOS syscall ABI（版本 1）  —— 与 Linux i386 `int 0x80` 约定相同
 * ===================================================================================
 *      eax            系统调用号（SYS_*）                      返回时：返回值
 *      ebx            参数 1
 *      ecx            参数 2
 *      edx            参数 3
 *      esi            参数 4
 *      edi            参数 5
 *      ebp            参数 6
 *
 *   - 返回值在 eax（32 位有符号）。>= 0 表示成功（含义由具体调用定义，如 write 返回字节数）；
 *     在 [-4095, -1] 之间表示出错，值是 -LUMA_Exxx（见下）。与 C 库的“返回 -1 并设 errno”
 *     不同，内核直接把错误号取负当返回值，没有 errno 全局变量（Ring 3 的程序不能共享内核变量）。
 *   - 保留寄存器：除 eax 外，所有通用寄存器（ebx ecx edx esi edi ebp esp）和段寄存器在
 *     `int 0x80` 前后保持不变；eflags 里的 IF/DF 等由 iret 恢复成调用前的值。
 *     因此调用者不需要把 ecx/edx 当“易失”寄存器保护起来（这与 cdecl 函数调用不同）。
 *   - 调用号不存在、或登记了但尚未实现 -> 返回 -LUMA_ENOSYS，内核状态不变。
 *   - 参数全部不可信：它们是程序随便填的整数。凡是“指针”，Day 51 的 sys_write 起必须先检查
 *     它指向的整块区域都在用户可访问范围内再读写（copy_from_user 的雏形）。
 *   - 调用号一经发布就不再改变含义（二进制兼容）；要改就换新号码，旧号码留空或返回 ENOSYS。
 *
 *  调用号表（今天的状态）：
 *      0  SYS_NOP      什么也不做，返回 0。用来测通道本身：进得去、出得来、寄存器没被弄坏。
 *      1  SYS_EXIT     [保留，Day 52 实现]  现在返回 -ENOSYS。
 *      2  SYS_WRITE    [保留，Day 51 实现]  现在返回 -ENOSYS。
 *      3  SYS_GETABI   返回 ABI 版本号（LUMA_SYSCALL_ABI_VERSION）。程序可据此判断内核支持什么。
 *
 * ===================================================================================
 *  今天的局限（后面几天逐个解决）
 * ===================================================================================
 *   - 程序仍在 Ring 0：`int 0x80` 同特权级进入，不换栈。内核处理函数因此运行在程序的用户栈上
 *     （这块 64KB 栈里多出约一百来字节 + C 函数的栈帧）。Day 55 降到 Ring 3 后，CPU 会按 TSS
 *     自动换成内核栈，这一点就没有了。
 *   - Day 46~49 的 luma_api_t 函数表还在；Day 51/52 把输出、退出搬到系统调用上之后，它才退役。
 *   - 参数里的指针今天没人用，所以还没有“用户指针检查”；写第一个带指针的调用（Day 51）时必须一并写。
 *   - 分发期间 IF=0（中断门）：键盘/鼠标/定时器不会在系统调用中途打断它。调用耗时长的操作（读盘）
 *     以后再考虑 sti 或换成陷阱门。
 */
#ifndef LUMA_SYSCALL_H
#define LUMA_SYSCALL_H

#include <stdint.h>

/* ---- 入口 ---- */
#define LUMA_SYSCALL_VECTOR       0x80u
#define LUMA_SYSCALL_ABI_VERSION  1

/* IDT 门的 type_attr：Present | DPL=3 | 32 位中断门 */
#define LUMA_SYSCALL_GATE_ATTR    0xEEu

/* ---- 调用号 ---- */
#define SYS_NOP      0
#define SYS_EXIT     1      /* Day 52 */
#define SYS_WRITE    2      /* Day 51 */
#define SYS_GETABI   3
#define LUMA_SYSCALL_MAX  32   /* 调用号 >= 它一律 -ENOSYS；表在 syscall.c */

/* ---- 错误号（返回 -LUMA_Exxx；数值沿用 Linux，方便对照资料） ---- */
#define LUMA_EFAULT   14     /* 指针指向不可访问的内存（Day 51 起使用） */
#define LUMA_EINVAL   22     /* 参数不合法 */
#define LUMA_ENOSYS   38     /* 没有这个系统调用 */

/* ---- 程序一侧的调用封装（内核自测、测试程序都用它）----
 * 程序是 -fno-pic 的静态可执行文件，ebx 可以直接做输入约束。 */
static inline int32_t luma_syscall0(uint32_t nr)
{
    int32_t r;
    __asm__ volatile ("int $0x80" : "=a"(r) : "a"(nr) : "memory");
    return r;
}
static inline int32_t luma_syscall3(uint32_t nr, uint32_t a1, uint32_t a2, uint32_t a3)
{
    int32_t r;
    __asm__ volatile ("int $0x80" : "=a"(r) : "a"(nr), "b"(a1), "c"(a2), "d"(a3) : "memory");
    return r;
}

#ifdef LUMA_KERNEL_SIDE
/* ---- 以下只给内核用 ---- */

/* 最近一次系统调用的记录 + 总数（sysstat 命令显示；测试靠它证明“确实进过内核”）。 */
typedef struct {
    uint32_t calls;          /* 进入 syscall_dispatch 的总次数 */
    uint32_t bad_calls;      /* 其中返回 -ENOSYS 的次数 */
    uint32_t last_nr;        /* 最近一次的调用号 */
    int32_t  last_ret;       /* 最近一次的返回值 */
    uint32_t last_args[6];   /* 最近一次的 6 个参数 */
    uint32_t last_eip;       /* 调用者执行 `int 0x80` 的下一条指令地址 */
    uint32_t last_cs;        /* 调用者的代码段（今天 0x08；Ring 3 时低 2 位 = 3） */
} syscall_stats_t;

typedef int32_t (*syscall_fn_t)(uint32_t a1, uint32_t a2, uint32_t a3,
                                uint32_t a4, uint32_t a5, uint32_t a6);

struct isr_context;
void syscall_dispatch(struct isr_context *ctx);       /* 由 isr_handler 在向量 0x80 时调用 */
const syscall_stats_t *syscall_get_stats(void);
void syscall_reset_stats(void);

/* 读 IDTR/IDT，取出 0x80 门的内容（诊断用）。 */
typedef struct { uint32_t handler; uint16_t selector; uint8_t type_attr; } syscall_gate_t;
void syscall_read_gate(syscall_gate_t *g);
#endif

#endif /* LUMA_SYSCALL_H */
